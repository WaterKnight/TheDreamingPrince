Mirror Of Truth
By bisnar13

Description:
A mirror of truth! Used also by mages, for seeing the past, future or current paths of something. It also answers questions.

Meant to be used as a mirror on the wall like in the fairy tales or something.
Another variation of the Crystal Lamp :)

Give credit if used :D

Updated: Added a portrait model, that you can use if you want it to have an aura around it :)

Updated: Allowed you to select it more easier :)

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2012, October 9
Model was last updated 2012, October 13


Visit http://www.hiveworkshop.com for more downloads